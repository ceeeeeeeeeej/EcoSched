import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../core/theme/app_theme.dart';

class GradientBackground extends StatefulWidget {
  final Widget child;
  final List<Color>? colors;
  final AlignmentGeometry? begin;
  final AlignmentGeometry? end;
  final bool showPattern;
  final double opacity;
  final bool animateGradient;
  final Duration animationDuration;
  final bool economyTheme;

  const GradientBackground({
    super.key,
    required this.child,
    this.colors,
    this.begin,
    this.end,
    this.showPattern = true,
    this.opacity = 1.0,
    this.animateGradient = true,
    this.animationDuration = const Duration(seconds: 10),
    this.economyTheme = false,
  });

  @override
  State<GradientBackground> createState() => _GradientBackgroundState();
}

class _GradientBackgroundState extends State<GradientBackground>
    with TickerProviderStateMixin {
  late AnimationController _gradientController;
  late AnimationController _particleController;
  late Animation<double> _gradientAnimation;
  late Animation<double> _particleAnimation;

  @override
  void initState() {
    super.initState();
    _gradientController = AnimationController(
      duration: widget.animationDuration,
      vsync: this,
    );
    _particleController = AnimationController(
      duration: const Duration(seconds: 8),
      vsync: this,
    );

    _gradientAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _gradientController,
      curve: Curves.easeInOut,
    ));

    _particleAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _particleController,
      curve: Curves.linear,
    ));

    if (widget.animateGradient) {
      _gradientController.repeat(reverse: true);
    }
    _particleController.repeat();
  }

  @override
  void dispose() {
    _gradientController.dispose();
    _particleController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([_gradientAnimation, _particleAnimation]),
      builder: (context, child) {
        return Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: _getAnimatedBegin(),
              end: _getAnimatedEnd(),
              colors: widget.colors ?? (widget.economyTheme ? _getEconomyGradient() : _getNatureGradient()),
              stops: const [0.0, 0.3, 0.7, 1.0],
            ),
          ),
          child: Stack(
            children: [
              if (widget.showPattern) _buildNaturePatternOverlay(),
              if (widget.showPattern) _buildFloatingParticles(),
              if (widget.showPattern) _buildFloatingLeaves(),
              if (widget.showPattern) _buildFloatingButterflies(),
              if (widget.showPattern) _buildLightRays(),
              if (widget.showPattern && widget.economyTheme) _buildEconomyGrid(),
              if (widget.showPattern && widget.economyTheme) _buildRisingArrows(),
              if (widget.showPattern && widget.economyTheme) _buildFloatingCoins(),
              Container(
                color: Colors.white.withOpacity(1.0 - widget.opacity),
                child: widget.child,
              ),
            ],
          ),
        );
      },
    );
  }

  AlignmentGeometry _getAnimatedBegin() {
    if (!widget.animateGradient) {
      return widget.begin ?? Alignment.topLeft;
    }
    
    final progress = _gradientAnimation.value;
    final angle = progress * 2 * math.pi;
    return Alignment(
      math.cos(angle) * 0.1,
      math.sin(angle) * 0.1,
    );
  }

  AlignmentGeometry _getAnimatedEnd() {
    if (!widget.animateGradient) {
      return widget.end ?? Alignment.bottomRight;
    }
    
    final progress = _gradientAnimation.value;
    final angle = progress * 2 * math.pi + math.pi;
    return Alignment(
      math.cos(angle) * 0.1,
      math.sin(angle) * 0.1,
    );
  }

  List<Color> _getNatureGradient() {
    return [
      const Color(0xFFE8F5E8), // Light mint
      const Color(0xFFF0F8F0), // Very light green
      const Color(0xFFF8FCF8), // Almost white with green tint
      const Color(0xFFFFFFFF), // Pure white
    ];
  }

  List<Color> _getEconomyGradient() {
    return [
      const Color(0xFFEFF9F4), // minty
      const Color(0xFFF8FBFF), // cool white
      const Color(0xFFFFFBF0), // soft gold tint
      const Color(0xFFFFFFFF), // white
    ];
  }

  Widget _buildNaturePatternOverlay() {
    return Positioned.fill(
      child: CustomPaint(
        painter: EnhancedNaturePatternPainter(
          animation: _particleAnimation,
        ),
      ),
    );
  }

  Widget _buildFloatingLeaves() {
    return Positioned.fill(
      child: CustomPaint(
        painter: FloatingLeavesPainter(
          animation: _particleAnimation,
        ),
      ),
    );
  }

  Widget _buildFloatingButterflies() {
    return Positioned.fill(
      child: CustomPaint(
        painter: FloatingButterfliesPainter(
          animation: _particleAnimation,
        ),
      ),
    );
  }

  Widget _buildLightRays() {
    return Positioned.fill(
      child: CustomPaint(
        painter: LightRaysPainter(
          animation: _particleAnimation,
        ),
      ),
    );
  }

  Widget _buildFloatingParticles() {
    return Positioned.fill(
      child: CustomPaint(
        painter: FloatingParticlesPainter(
          animation: _particleAnimation,
        ),
      ),
    );
  }

  Widget _buildEconomyGrid() {
    return Positioned.fill(
      child: CustomPaint(
        painter: EconomyGridPainter(
          animation: _particleAnimation,
        ),
      ),
    );
  }

  Widget _buildRisingArrows() {
    return Positioned.fill(
      child: CustomPaint(
        painter: RisingArrowsPainter(
          animation: _particleAnimation,
        ),
      ),
    );
  }

  Widget _buildFloatingCoins() {
    return Positioned.fill(
      child: CustomPaint(
        painter: FloatingCoinsPainter(
          animation: _particleAnimation,
        ),
      ),
    );
  }
}

class EnhancedNaturePatternPainter extends CustomPainter {
  final Animation<double> animation;

  EnhancedNaturePatternPainter({required this.animation});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppTheme.primaryGreen.withOpacity(0.02)
      ..style = PaintingStyle.fill;

    // Draw organic dot pattern with varying sizes
    for (double x = 0; x < size.width; x += 30) {
      for (double y = 0; y < size.height; y += 30) {
        final offset = math.sin(x * 0.01 + animation.value * 2) * 5;
        final radius = 1.0 + math.sin(x * 0.02 + y * 0.02) * 0.5;
        canvas.drawCircle(Offset(x + offset, y), radius, paint);
      }
    }

    // Draw subtle leaf silhouettes
    final leafPaint = Paint()
      ..color = AppTheme.primaryGreen.withOpacity(0.015)
      ..style = PaintingStyle.fill;

    for (int i = 0; i < 8; i++) {
      final x = (i * 150.0) % size.width;
      final y = (i * 200.0) % size.height;
      final rotation = animation.value * 2 * math.pi + i;
      
      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(rotation);
      canvas.scale(0.3 + 0.2 * math.sin(animation.value * math.pi + i));
      _drawLeafSilhouette(canvas, leafPaint);
      canvas.restore();
    }
  }

  void _drawLeafSilhouette(Canvas canvas, Paint paint) {
    final path = Path();
    path.moveTo(0, -8);
    path.quadraticBezierTo(6, -4, 8, 0);
    path.quadraticBezierTo(6, 4, 0, 8);
    path.quadraticBezierTo(-6, 4, -8, 0);
    path.quadraticBezierTo(-6, -4, 0, -8);
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class FloatingLeavesPainter extends CustomPainter {
  final Animation<double> animation;

  FloatingLeavesPainter({required this.animation});

  @override
  void paint(Canvas canvas, Size size) {
    final leafCount = 6;
    for (int i = 0; i < leafCount; i++) {
      final progress = (animation.value + i / leafCount) % 1.0;
      final x = (i * 200.0) % size.width;
      final y = progress * size.height;
      final rotation = progress * 2 * math.pi + i;
      final scale = 0.4 + 0.3 * math.sin(progress * math.pi);
      final opacity = (1.0 - progress).clamp(0.0, 1.0);

      final paint = Paint()
        ..color = AppTheme.primaryGreen.withOpacity(0.3 * opacity)
        ..style = PaintingStyle.fill;

      canvas.save();
      canvas.translate(x, y);
      canvas.rotate(rotation);
      canvas.scale(scale);
      _drawLeaf(canvas, paint);
      canvas.restore();
    }
  }

  void _drawLeaf(Canvas canvas, Paint paint) {
    final path = Path();
    path.moveTo(0, -10);
    path.quadraticBezierTo(8, -5, 10, 0);
    path.quadraticBezierTo(8, 5, 0, 10);
    path.quadraticBezierTo(-8, 5, -10, 0);
    path.quadraticBezierTo(-8, -5, 0, -10);
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class FloatingButterfliesPainter extends CustomPainter {
  final Animation<double> animation;

  FloatingButterfliesPainter({required this.animation});

  @override
  void paint(Canvas canvas, Size size) {
    final butterflyCount = 3;
    for (int i = 0; i < butterflyCount; i++) {
      final progress = (animation.value + i / butterflyCount) % 1.0;
      final x = (i * 300.0) % size.width + 50 * math.sin(progress * 4 * math.pi);
      final y = progress * size.height;
      final wingFlap = math.sin(progress * 8 * math.pi);
      final opacity = (1.0 - progress).clamp(0.0, 1.0);

      final paint = Paint()
        ..color = AppTheme.accentOrange.withOpacity(0.4 * opacity)
        ..style = PaintingStyle.fill;

      canvas.save();
      canvas.translate(x, y);
      canvas.scale(0.3 + 0.2 * wingFlap);
      _drawButterfly(canvas, paint, wingFlap);
      canvas.restore();
    }
  }

  void _drawButterfly(Canvas canvas, Paint paint, double wingFlap) {
    // Body
    canvas.drawOval(Rect.fromCenter(center: Offset.zero, width: 2, height: 8), paint);
    
    // Wings
    final wingPaint = Paint()
      ..color = paint.color.withOpacity(0.7)
      ..style = PaintingStyle.fill;

    // Top wings
    canvas.save();
    canvas.scale(1.0 + wingFlap * 0.3, 1.0);
    canvas.drawOval(Rect.fromCenter(center: const Offset(-4, -2), width: 6, height: 4), wingPaint);
    canvas.drawOval(Rect.fromCenter(center: const Offset(4, -2), width: 6, height: 4), wingPaint);
    canvas.restore();

    // Bottom wings
    canvas.save();
    canvas.scale(1.0 - wingFlap * 0.2, 1.0);
    canvas.drawOval(Rect.fromCenter(center: const Offset(-3, 1), width: 5, height: 3), wingPaint);
    canvas.drawOval(Rect.fromCenter(center: const Offset(3, 1), width: 5, height: 3), wingPaint);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class LightRaysPainter extends CustomPainter {
  final Animation<double> animation;

  LightRaysPainter({required this.animation});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppTheme.primaryGreen.withOpacity(0.1)
      ..style = PaintingStyle.fill;

    final rayCount = 4;
    for (int i = 0; i < rayCount; i++) {
      final angle = (i * math.pi / rayCount) + animation.value * 0.1;
      final centerX = size.width * 0.3;
      final centerY = size.height * 0.2;
      
      canvas.save();
      canvas.translate(centerX, centerY);
      canvas.rotate(angle);
      
      final path = Path();
      path.moveTo(0, 0);
      path.lineTo(-20, -size.height * 0.8);
      path.lineTo(20, -size.height * 0.8);
      path.close();
      
      canvas.drawPath(path, paint);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class FloatingParticlesPainter extends CustomPainter {
  final Animation<double> animation;

  FloatingParticlesPainter({required this.animation});

  @override
  void paint(Canvas canvas, Size size) {
    final particleCount = 20;
    final colors = [
      AppTheme.primaryGreen,
      AppTheme.accentOrange,
      AppTheme.accentBlue,
      AppTheme.primaryGreenLight,
    ];

    for (int i = 0; i < particleCount; i++) {
      final progress = (animation.value + i / particleCount) % 1.0;
      final x = (i * 120.0) % size.width + 30 * math.sin(progress * 2 * math.pi);
      final y = progress * size.height;
      final radius = 1.5 + (i % 4) * 0.8;
      final opacity = (1.0 - progress).clamp(0.0, 1.0);
      final colorIndex = i % colors.length;
      
      final paint = Paint()
        ..color = colors[colorIndex].withOpacity(0.15 * opacity)
        ..style = PaintingStyle.fill;

      // Draw different particle shapes
      if (i % 3 == 0) {
        // Draw flower-like particles
        _drawFlowerParticle(canvas, Offset(x, y), radius, paint);
      } else if (i % 3 == 1) {
        // Draw star-like particles
        _drawStarParticle(canvas, Offset(x, y), radius, paint);
      } else {
        // Draw regular circles
        canvas.drawCircle(Offset(x, y), radius, paint);
      }
    }
  }

  void _drawFlowerParticle(Canvas canvas, Offset center, double radius, Paint paint) {
    final petalCount = 5;
    for (int i = 0; i < petalCount; i++) {
      final angle = (i * 2 * math.pi) / petalCount;
      canvas.save();
      canvas.translate(center.dx, center.dy);
      canvas.rotate(angle);
      canvas.drawOval(Rect.fromCenter(center: Offset(radius * 0.5, 0), width: radius, height: radius * 0.3), paint);
      canvas.restore();
    }
    // Center
    canvas.drawCircle(center, radius * 0.3, paint);
  }

  void _drawStarParticle(Canvas canvas, Offset center, double radius, Paint paint) {
    final path = Path();
    final outerRadius = radius;
    final innerRadius = radius * 0.4;
    final points = 5;
    
    for (int i = 0; i < points * 2; i++) {
      final angle = (i * math.pi) / points;
      final r = i.isEven ? outerRadius : innerRadius;
      final x = center.dx + r * math.cos(angle);
      final y = center.dy + r * math.sin(angle);
      
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class EconomyGridPainter extends CustomPainter {
  final Animation<double> animation;

  EconomyGridPainter({required this.animation});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.black.withOpacity(0.03)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    const double grid = 40;
    final double shift = (animation.value * grid);

    for (double x = -grid + shift; x < size.width; x += grid) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = -grid + shift; y < size.height; y += grid) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    // Subtle upward trend line
    final trend = Path();
    final trendPaint = Paint()
      ..color = const Color(0xFF2E7D32).withOpacity(0.10)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;

    trend.moveTo(0, size.height * 0.75);
    for (double x = 0; x <= size.width; x += 20) {
      final t = x / size.width;
      final y = size.height * (0.75 - 0.25 * t + 0.02 * math.sin(t * math.pi * 4 + animation.value * math.pi * 2));
      trend.lineTo(x, y);
    }
    canvas.drawPath(trend, trendPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class RisingArrowsPainter extends CustomPainter {
  final Animation<double> animation;

  RisingArrowsPainter({required this.animation});

  @override
  void paint(Canvas canvas, Size size) {
    final arrowCount = 6;
    for (int i = 0; i < arrowCount; i++) {
      final progress = (animation.value + i / arrowCount) % 1.0;
      final x = (i * (size.width / arrowCount)) + 20 * math.sin(progress * 2 * math.pi);
      final y = size.height * (1.0 - progress);
      final opacity = (0.3 * (1.0 - progress)).clamp(0.05, 0.25);

      final paint = Paint()
        ..color = const Color(0xFFFFA000).withOpacity(opacity)
        ..style = PaintingStyle.fill;

      _drawArrow(canvas, Offset(x, y), 10 + 10 * (1 - progress), paint);
    }
  }

  void _drawArrow(Canvas canvas, Offset center, double size, Paint paint) {
    final path = Path();
    path.moveTo(center.dx, center.dy - size);
    path.lineTo(center.dx - size * 0.6, center.dy);
    path.lineTo(center.dx - size * 0.2, center.dy);
    path.lineTo(center.dx - size * 0.2, center.dy + size);
    path.lineTo(center.dx + size * 0.2, center.dy + size);
    path.lineTo(center.dx + size * 0.2, center.dy);
    path.lineTo(center.dx + size * 0.6, center.dy);
    path.close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class FloatingCoinsPainter extends CustomPainter {
  final Animation<double> animation;

  FloatingCoinsPainter({required this.animation});

  @override
  void paint(Canvas canvas, Size size) {
    final coinCount = 10;
    for (int i = 0; i < coinCount; i++) {
      final progress = (animation.value + i / coinCount) % 1.0;
      final x = (i * (size.width / coinCount)) + 30 * math.sin(progress * 2 * math.pi);
      final y = size.height * (1.1 - progress);
      final radius = 4.0 + (i % 3) * 1.5;
      final paint = Paint()
        ..shader = const RadialGradient(
          colors: [Color(0xFFFFF3CD), Color(0xFFFFD54F), Color(0xFFFFA000)],
        ).createShader(Rect.fromCircle(center: Offset(x, y), radius: radius * 2))
        ..style = PaintingStyle.fill
        ..color = const Color(0xFFFFD54F).withOpacity(0.8);

      _drawCoin(canvas, Offset(x, y), radius, paint);
    }
  }

  void _drawCoin(Canvas canvas, Offset center, double radius, Paint paint) {
    canvas.drawCircle(center, radius, paint);
    final rimPaint = Paint()
      ..color = const Color(0xFFFFA000).withOpacity(0.6)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    canvas.drawCircle(center, radius, rimPaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}