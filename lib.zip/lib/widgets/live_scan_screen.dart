import 'dart:async';
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:google_generative_ai/google_generative_ai.dart';
import '../core/services/ai_chat_service.dart';
import '../core/error/error_handler.dart';
import '../core/theme/app_theme.dart';

class LiveScanResult {
  final Uint8List imageBytes;
  final String reply;
  LiveScanResult({required this.imageBytes, required this.reply});
}

class LiveScanScreen extends StatefulWidget {
  final String apiKey;
  const LiveScanScreen({super.key, required this.apiKey});

  @override
  State<LiveScanScreen> createState() => _LiveScanScreenState();
}

class _LiveScanScreenState extends State<LiveScanScreen> {
  CameraController? _controller;
  Future<void>? _initFuture;
  bool _isScanning = false;
  Timer? _autoTimer;
  String? _lastReply;
  late final AiChatService _chatService;

  @override
  void initState() {
    super.initState();
    _chatService = AiChatService(widget.apiKey);
    _initFuture = _initCamera();
  }

  Future<void> _initCamera() async {
    try {
      final PermissionStatus cam = await Permission.camera.request();
      if (!cam.isGranted) {
        throw Exception('Camera permission denied');
      }
      final List<CameraDescription> cameras = await availableCameras();
      final CameraDescription camera = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first,
      );
      _controller = CameraController(camera, ResolutionPreset.medium, enableAudio: false);
      await _controller!.initialize();
      if (mounted) setState(() {});
    } catch (e) {
      ErrorHandler.handleError(e, StackTrace.current, context: 'Init camera');
    }
  }

  Future<void> _scanOnce() async {
    if (_controller == null || !_controller!.value.isInitialized || _isScanning) return;
    setState(() => _isScanning = true);
    try {
      final XFile file = await _controller!.takePicture();
      final Uint8List bytes = await file.readAsBytes();
      final String prompt = 'Classify the waste item as biodegradable, non-biodegradable (recyclable or not), or hazardous. '
          'Return a short, specific disposal tip for Tago. Keep reply to 1–2 sentences.';
      final reply = await _chatService.sendMessageWithImages(prompt, [DataPart('image/jpeg', bytes)]);
      if (mounted) {
        setState(() {
          _lastReply = reply;
        });
      }
    } catch (e) {
      ErrorHandler.handleError(e, StackTrace.current, context: 'Live scan');
    } finally {
      if (mounted) setState(() => _isScanning = false);
    }
  }

  void _toggleAuto() {
    if (_autoTimer != null) {
      _autoTimer!.cancel();
      _autoTimer = null;
      setState(() {});
      return;
    }
    _autoTimer = Timer.periodic(const Duration(seconds: 3), (_) => _scanOnce());
    setState(() {});
  }

  @override
  void dispose() {
    _autoTimer?.cancel();
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Live Scan'),
        actions: [
          IconButton(
            tooltip: _autoTimer == null ? 'Start auto-scan' : 'Stop auto-scan',
            icon: Icon(_autoTimer == null ? Icons.play_circle_outline : Icons.pause_circle_outline),
            onPressed: _toggleAuto,
          ),
        ],
      ),
      body: FutureBuilder(
        future: _initFuture,
        builder: (context, snapshot) {
          if (_controller == null || !_controller!.value.isInitialized) {
            return const Center(child: CircularProgressIndicator());
          }
          return Stack(
            children: [
              Positioned.fill(child: CameraPreview(_controller!)),
              if (_lastReply != null)
                Positioned(
                  left: 16,
                  right: 16,
                  bottom: 120,
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      _lastReply!,
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
          child: ElevatedButton.icon(
            onPressed: _isScanning ? null : _scanOnce,
            icon: _isScanning
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.search),
            label: const Text('Scan'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _isScanning ? null : _scanOnce,
        backgroundColor: AppTheme.primaryGreen,
        foregroundColor: Colors.white,
        child: _isScanning
            ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            : const Icon(Icons.camera_alt),
      ),
    );
  }
}


