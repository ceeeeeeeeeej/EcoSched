import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../../widgets/enhanced_nature_background.dart';
import '../../../widgets/glassmorphic_container.dart';
import '../../../widgets/animated_button.dart';
import '../../../widgets/nature_animations.dart';
import '../../../core/transitions/nature_transitions.dart';
import '../../../core/error/error_handler.dart';
import '../../../core/services/auth_service.dart';
import 'package:provider/provider.dart';
import '../../../core/routes/app_router.dart';

class ResidentLocationSelectionScreen extends StatefulWidget {
  final String? selectedBarangay;
  
  const ResidentLocationSelectionScreen({
    super.key,
    this.selectedBarangay,
  });

  @override
  State<ResidentLocationSelectionScreen> createState() => _ResidentLocationSelectionScreenState();
}

class _ResidentLocationSelectionScreenState extends State<ResidentLocationSelectionScreen>
    with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();
  
  bool _isLoading = false;
  
  String? _selectedBarangay;
  String? _selectedPurok;
  
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // Dummy purok lists
  final List<String> _victoriaPuroks = [
    'Purok 1',
    'Purok 2',
    'Purok 3',
    'Purok 4',
    'Purok 5',
  ];

  final List<String> _dayoAnPuroks = [
    'Purok 1',
    'Purok 2',
    'Purok 3',
    'Purok 4',
  ];

  List<String> get _availablePuroks {
    if (_selectedBarangay == 'Victoria') {
      return _victoriaPuroks;
    } else if (_selectedBarangay == 'Dayo-an') {
      return _dayoAnPuroks;
    }
    return [];
  }

  @override
  void initState() {
    super.initState();
    
    // Pre-select barangay if provided
    if (widget.selectedBarangay != null) {
      _selectedBarangay = widget.selectedBarangay;
    }
    
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    ));

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _fadeController.forward();
    _slideController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  Future<void> _handleLocationSelection() async {
    if (!_formKey.currentState!.validate()) return;

    if (_selectedBarangay == null) {
      ErrorHandler.showErrorSnackBar(
        context,
        'Please select your barangay',
      );
      return;
    }

    if (_selectedPurok == null) {
      ErrorHandler.showErrorSnackBar(
        context,
        'Please select your purok',
      );
      return;
    }

    final authService = Provider.of<AuthService>(context, listen: false);
    
    setState(() {
      _isLoading = true;
    });

    try {
      // Store location data without authentication
      authService.setResidentLocation(
        barangay: _selectedBarangay!,
        purok: _selectedPurok!,
      );
      
      if (mounted) {
        ErrorHandler.showSuccessSnackBar(
          context,
          'Welcome to EcoSched!',
        );
        
        Navigator.of(context).pushNamedAndRemoveUntil(
          AppRoutes.residentDashboard,
          (route) => false,
        );
      }
    } catch (error) {
      if (mounted) {
        ErrorHandler.showErrorSnackBar(
          context,
          'Failed to proceed. Please try again.',
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: EnhancedNatureBackground(
        showPattern: true,
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: EdgeInsets.all(AppTheme.spacing8), 
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const SizedBox(height: 40),
                  
                  // App Logo and Title with Nature Animation
                  FadeTransition(
                    opacity: _fadeAnimation,
                    child: SlideTransition(
                      position: _slideAnimation,
                      child: Column(
                        children: [
                          NatureHeroAnimation(
                            tag: 'resident_location_logo',
                            child: EcoPulseAnimation(
                              isActive: true,
                              child: NatureRippleEffect(
                                rippleColor: AppTheme.accentOrange,
                                child: Container(
                                  width: 100,
                                  height: 100,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: AppTheme.primaryGradient,
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                    ),
                                    borderRadius: BorderRadius.circular(25),
                                    boxShadow: [
                                      BoxShadow(
                                        color: AppTheme.accentOrange.withOpacity(0.3),
                                        blurRadius: 20,
                                        offset: const Offset(0, 10),
                                      ),
                                    ],
                                  ),
                                  child: const Icon(
                                    Icons.location_on,
                                    size: 50,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 24),
                          NatureBounceAnimation(
                            isActive: true,
                            child: Text(
                              'Select Your Location',
                              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                                fontWeight: FontWeight.w700,
                                color: AppTheme.textDark,
                                letterSpacing: -0.5,
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          EcoShimmerEffect(
                            isActive: true,
                            baseColor: AppTheme.textLight.withOpacity(0.3),
                            highlightColor: AppTheme.textLight,
                            child: Text(
                              'Choose where you live',
                              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                                color: AppTheme.textLight,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 40),
                  
                  // Location Selection Form Container with Nature Animation
                  FadeTransition(
                    opacity: _fadeAnimation,
                    child: SlideTransition(
                      position: _slideAnimation,
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 400),
                        child: NatureRippleEffect(
                          rippleColor: AppTheme.accentOrange.withOpacity(0.3),
                          child: GlassmorphicContainer(
                            width: double.infinity,
                            padding: EdgeInsets.all(AppTheme.spacing8), 
                            borderRadius: AppTheme.radiusL,
                            child: Form(
                              key: _formKey,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  // Barangay Selection
                                  Text(
                                    'Barangay',
                                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.textDark,
                                    ),
                                  ),
                                  const SizedBox(height: 12),
                                  // Victoria Option
                                  _buildBarangayOption(
                                    'Victoria',
                                    Icons.location_city,
                                    AppTheme.primaryGreen,
                                  ),
                                  const SizedBox(height: 12),
                                  // Dayo-an Option
                                  _buildBarangayOption(
                                    'Dayo-an',
                                    Icons.location_city,
                                    AppTheme.accentOrange,
                                  ),
                                  const SizedBox(height: 24),
                                  
                                  // Purok Selection (shown only when barangay is selected)
                                  if (_selectedBarangay != null) ...[
                                    DropdownButtonFormField<String>(
                                      initialValue: _selectedPurok,
                                      decoration: InputDecoration(
                                        labelText: 'Purok',
                                        hintText: 'Select your purok',
                                        prefixIcon: const Icon(Icons.home_outlined),
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(AppTheme.radiusM),
                                        ),
                                      ),
                                      items: _availablePuroks.map((purok) {
                                        return DropdownMenuItem<String>(
                                          value: purok,
                                          child: Text(purok),
                                        );
                                      }).toList(),
                                      onChanged: (value) {
                                        setState(() {
                                          _selectedPurok = value;
                                        });
                                      },
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please select your purok';
                                        }
                                        return null;
                                      },
                                    ),
                                  ],
                                  const SizedBox(height: 24),
                                  
                                  // Continue Button with Nature Animation
                                  NatureRippleEffect(
                                    rippleColor: AppTheme.accentOrange,
                                    child: AnimatedButton(
                                      text: 'Continue',
                                      onPressed: _isLoading ? null : _handleLocationSelection,
                                      isLoading: _isLoading,
                                      width: double.infinity,
                                      icon: Icons.arrow_forward,
                                      backgroundColor: AppTheme.accentOrange,
                                      isGradient: true,
                                      gradientColors: AppTheme.primaryGradient,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 30),
                  
                  // Back to Role Selection
                  FadeTransition(
                    opacity: _fadeAnimation,
                    child: NatureBounceAnimation(
                      isActive: true,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            'Want to register as a collector? ',
                            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: AppTheme.textMuted,
                            ),
                          ),
                          GestureDetector(
                            onTap: () => Navigator.of(context).pop(),
                            child: NatureRippleEffect(
                              rippleColor: AppTheme.accentOrange,
                              child: Text(
                                'Go Back',
                                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                                  color: AppTheme.accentOrange,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBarangayOption(String barangay, IconData icon, Color color) {
    final isSelected = _selectedBarangay == barangay;
    
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedBarangay = barangay;
          _selectedPurok = null; // Reset purok when barangay changes
        });
      },
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected 
              ? color.withOpacity(0.1) 
              : Colors.white.withOpacity(0.1),
          borderRadius: BorderRadius.circular(AppTheme.radiusM),
          border: Border.all(
            color: isSelected 
                ? color 
                : Colors.white.withOpacity(0.2),
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: isSelected 
                    ? color.withOpacity(0.2) 
                    : Colors.white.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                icon,
                color: isSelected ? color : AppTheme.textLight,
                size: 24,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                barangay,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                  color: isSelected ? color : AppTheme.textDark,
                ),
              ),
            ),
            if (isSelected)
              Icon(
                Icons.check_circle,
                color: color,
                size: 24,
              ),
          ],
        ),
      ),
    );
  }
}

