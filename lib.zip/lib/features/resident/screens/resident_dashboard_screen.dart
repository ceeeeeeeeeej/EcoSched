import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/routes/app_router.dart';
import '../../../core/utils/responsive.dart';
import '../../../widgets/live_scan_screen.dart';
import '../../../widgets/gradient_background.dart';

class ResidentDashboardScreen extends StatefulWidget {
  const ResidentDashboardScreen({super.key});

  @override
  State<ResidentDashboardScreen> createState() =>
      _ResidentDashboardScreenState();
}

class _ResidentDashboardScreenState extends State<ResidentDashboardScreen> {
  int currentPage = 0;
  int currentNavIndex = 0;

  final List<Widget> pages = const [
    _HomePage(),
    _FeedbackPage(),
    _CompostPitsPage(),
    _NotificationsPage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: AnimatedSwitcher(
        duration: const Duration(milliseconds: 300),
        child: pages[currentPage],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentNavIndex,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: AppTheme.primary,
        unselectedItemColor: AppTheme.textLight,
        showUnselectedLabels: true,
        onTap: (navIndex) {
          if (navIndex == 2) {
            _openLiveScan(context);
            return;
          }

          final mappedPageIndex = _mapNavIndexToPageIndex(navIndex);
          setState(() {
            currentNavIndex = navIndex;
            currentPage = mappedPageIndex;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_rounded),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.article_rounded),
            label: 'Reports',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.camera_alt_rounded),
            label: 'Scan',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.eco_rounded),
            label: 'Eco',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications_none_rounded),
            label: 'Alerts',
          ),
        ],
      ),
    );
  }

  void _openLiveScan(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => LiveScanScreen(apiKey: AppConstants.geminiApiKey),
        fullscreenDialog: true,
      ),
    );
  }

  int _mapNavIndexToPageIndex(int navIndex) {
    switch (navIndex) {
      case 0:
        return 0; // Home
      case 1:
        return 1; // Reports/Feedback
      case 3:
        return 2; // Eco / Compost Pits
      case 4:
        return 3; // Alerts / Notifications
      default:
        return currentPage;
    }
  }

  Widget _buildGifNavItem(String assetPath, {bool isEmphasized = false}) {
    final double size = isEmphasized ? 34 : 28;
    return SizedBox(
      width: size,
      height: size,
      child: Image.asset(
        assetPath,
        fit: BoxFit.contain,
      ),
    );
  }
}

class _NavItemData {
  final IconData icon;
  final String label;

  const _NavItemData({
    required this.icon,
    required this.label,
  });
}

class _EcoNavigationBar extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onItemSelected;
  final VoidCallback onLiveScanPressed;

  const _EcoNavigationBar({
    required this.currentIndex,
    required this.onItemSelected,
    required this.onLiveScanPressed,
  });

  @override
  Widget build(BuildContext context) {
    const navItems = [
      _NavItemData(icon: Icons.home_rounded, label: 'Home'),
      _NavItemData(icon: Icons.article_rounded, label: 'Reports'),
      _NavItemData(icon: Icons.eco_rounded, label: 'Eco'),
      _NavItemData(icon: Icons.notifications_none_rounded, label: 'Alerts'),
    ];

    return Container(
      height: 96,
      padding: const EdgeInsets.symmetric(
        horizontal: AppTheme.spacing6,
        vertical: AppTheme.spacing2,
      ),
      child: Stack(
        clipBehavior: Clip.none,
        alignment: Alignment.center,
        children: [
          Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppTheme.primary, AppTheme.primaryDark],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(AppTheme.radius2XL),
              border: Border.all(
                color: Colors.white.withOpacity(0.12),
                width: 1,
              ),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x33000000),
                  blurRadius: 18,
                  offset: Offset(0, 8),
                ),
              ],
            ),
            padding: const EdgeInsets.symmetric(
              horizontal: AppTheme.spacing6,
              vertical: AppTheme.spacing1,
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                for (var i = 0; i < navItems.length; i++) ...[
                  _NavIconButton(
                    icon: navItems[i].icon,
                    label: navItems[i].label,
                    isSelected: currentIndex == i,
                    onTap: () => onItemSelected(i),
                  ),
                  if (i == 1)
                    const SizedBox(width: 66), // space for floating camera
                ],
              ],
            ),
          ),

          /// Floating Camera Button
          AnimatedPositioned(
            duration: const Duration(milliseconds: 260),
            curve: Curves.easeOutBack,
            // When Home (index 0) is selected, bring the camera noticeably closer to the bar
            top: currentIndex == 0 ? -4 : -26,
            child: GestureDetector(
              onTap: onLiveScanPressed,
              child: Container(
                width: 66,
                height: 66,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.accentBlue.withOpacity(0.35),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Container(
                  margin: const EdgeInsets.all(5),
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [AppTheme.accentBlue, AppTheme.secondary],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.camera_alt_rounded,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _NavIconButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _NavIconButton({
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final Color activeColor = Colors.white;
    final Color inactiveColor = Colors.white.withOpacity(0.7);

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color:
              isSelected ? Colors.white.withOpacity(0.18) : Colors.transparent,
          borderRadius: BorderRadius.circular(24),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isSelected ? activeColor : inactiveColor,
              size: 24,
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: isSelected ? activeColor : inactiveColor,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                  ),
            ),
          ],
        ),
      ),
    );
  }
}

// Home Page Widget
class _HomePage extends StatelessWidget {
  const _HomePage();

  @override
  Widget build(BuildContext context) {
    final responsive = context.responsive;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'EcoSched',
                  style: AppTheme.titleLarge.copyWith(
                    color: AppTheme.textInverse,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(AppTheme.radiusM),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Image.asset(
                    'assets/images/house.gif',
                    fit: BoxFit.cover,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 2),
          ],
        ),
        centerTitle: false,
        backgroundColor: AppTheme.primaryGreen,
        elevation: 0,
      ),
      backgroundColor: AppTheme.background,
      body: GradientBackground(
        economyTheme: true,
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              return SingleChildScrollView(
                padding: EdgeInsets.symmetric(
                  horizontal: responsive.horizontalPadding,
                  vertical: responsive.verticalPadding,
                ),
                child: ConstrainedBox(
                  constraints: BoxConstraints(minHeight: constraints.maxHeight),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Welcome Section
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.all(responsive.spacing(24)),
                        decoration: BoxDecoration(
                          color: AppTheme.cardWhite,
                          borderRadius:
                              BorderRadius.circular(AppTheme.radiusXL),
                          boxShadow: AppTheme.shadowMedium,
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Welcome back, Sarah!',
                              style: AppTheme.headlineSmall.copyWith(
                                color: AppTheme.textDark,
                                fontSize: AppTheme.headlineSmall.fontSize! *
                                    responsive.fontSizeMultiplier,
                              ),
                            ),
                            SizedBox(height: responsive.spacing(8)),
                            Text(
                              'Access your waste management tools and services',
                              style: AppTheme.bodyMedium.copyWith(
                                color: AppTheme.textLight,
                                fontSize: AppTheme.bodyMedium.fontSize! *
                                    responsive.fontSizeMultiplier,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: responsive.spacing(32)),

                      // Quick Actions
                      Text(
                        'Quick Actions',
                        style: AppTheme.titleLarge.copyWith(
                          color: AppTheme.textDark,
                          fontSize: AppTheme.titleLarge.fontSize! *
                              responsive.fontSizeMultiplier,
                        ),
                      ),
                      SizedBox(height: responsive.spacing(16)),

                      // Action Buttons - Responsive layout
                      responsive.isMobile
                          ? Column(
                              children: [
                                _buildActionButton(
                                  context,
                                  'Schedule Pickup',
                                  Icons.schedule,
                                  AppTheme.primaryGreen,
                                  () {
                                    Navigator.of(context)
                                        .pushNamed(AppRoutes.schedulePickup);
                                  },
                                  responsive,
                                ),
                                SizedBox(height: responsive.spacing(16)),
                                _buildActionButton(
                                  context,
                                  'View Collection History',
                                  Icons.history,
                                  AppTheme.lightGreen,
                                  () {
                                    Navigator.of(context).pushNamed(
                                      AppRoutes.residentCollectionHistory,
                                    );
                                  },
                                  responsive,
                                ),
                              ],
                            )
                          : Row(
                              children: [
                                Expanded(
                                  child: _buildActionButton(
                                    context,
                                    'Schedule Pickup',
                                    Icons.schedule,
                                    AppTheme.primaryGreen,
                                    () {
                                      Navigator.of(context)
                                          .pushNamed(AppRoutes.schedulePickup);
                                    },
                                    responsive,
                                  ),
                                ),
                                SizedBox(width: responsive.spacing(16)),
                                Expanded(
                                  child: _buildActionButton(
                                    context,
                                    'View Collection History',
                                    Icons.history,
                                    AppTheme.lightGreen,
                                    () {
                                      Navigator.of(context).pushNamed(
                                        AppRoutes.residentCollectionHistory,
                                      );
                                    },
                                    responsive,
                                  ),
                                ),
                              ],
                            ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildActionButton(BuildContext context, String title, IconData icon,
      Color color, VoidCallback onTap, Responsive responsive) {
    return SizedBox(
      width: double.infinity,
      height: responsive.isMobile ? 60 : 70,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: color,
          foregroundColor: AppTheme.textInverse,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppTheme.radiusL),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon,
                size: responsive.iconSize(24), color: AppTheme.textInverse),
            SizedBox(width: responsive.spacing(12)),
            Flexible(
              child: Text(
                title,
                style: AppTheme.titleMedium.copyWith(
                  color: AppTheme.textInverse,
                  fontSize: AppTheme.titleMedium.fontSize! *
                      responsive.fontSizeMultiplier,
                ),
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Feedback Page Widget
class _FeedbackPage extends StatelessWidget {
  const _FeedbackPage();

  @override
  Widget build(BuildContext context) {
    final responsive = context.responsive;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'EcoSched',
                  style: AppTheme.titleLarge.copyWith(
                    color: AppTheme.textInverse,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(AppTheme.radiusM),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Image.asset(
                    'assets/images/house.gif',
                    fit: BoxFit.cover,
                  ),
                ),
              ],
            ),
          ],
        ),
        centerTitle: false,
        backgroundColor: AppTheme.primaryGreen,
        foregroundColor: AppTheme.textInverse,
      ),
      backgroundColor: Colors.grey[50],
      body: GradientBackground(
        economyTheme: true,
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              return SingleChildScrollView(
                padding: EdgeInsets.symmetric(
                  horizontal: responsive.horizontalPadding,
                  vertical: responsive.verticalPadding,
                ),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight: constraints.maxHeight,
                    maxWidth: responsive.getContainerWidth(
                      mobilePercent: 1.0,
                      tabletPercent: 0.8,
                      desktopPercent: 0.6,
                      maxWidth: 600,
                    ),
                  ),
                  child: Column(
                    children: [
                      // Feedback Form
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.all(responsive.spacing(24)),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 10,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Share Your Feedback',
                              style: Theme.of(context)
                                  .textTheme
                                  .headlineSmall
                                  ?.copyWith(
                                    fontWeight: FontWeight.bold,
                                    color: AppTheme.textDark,
                                    fontSize: (Theme.of(context)
                                                .textTheme
                                                .headlineSmall
                                                ?.fontSize ??
                                            24) *
                                        responsive.fontSizeMultiplier,
                                  ),
                            ),
                            SizedBox(height: responsive.spacing(16)),
                            TextFormField(
                              style: TextStyle(
                                  fontSize: 14 * responsive.fontSizeMultiplier),
                              decoration: InputDecoration(
                                labelText: 'Subject',
                                labelStyle: TextStyle(
                                    fontSize:
                                        14 * responsive.fontSizeMultiplier),
                                border: const OutlineInputBorder(),
                                prefixIcon: Icon(Icons.subject,
                                    size: responsive.iconSize(20)),
                              ),
                            ),
                            SizedBox(height: responsive.spacing(16)),
                            TextFormField(
                              maxLines: responsive.isMobile ? 4 : 5,
                              style: TextStyle(
                                  fontSize: 14 * responsive.fontSizeMultiplier),
                              decoration: InputDecoration(
                                labelText: 'Your Message',
                                labelStyle: TextStyle(
                                    fontSize:
                                        14 * responsive.fontSizeMultiplier),
                                border: const OutlineInputBorder(),
                                prefixIcon: Icon(Icons.message,
                                    size: responsive.iconSize(20)),
                              ),
                            ),
                            SizedBox(height: responsive.spacing(20)),
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                onPressed: () {
                                  // Handle feedback submission
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        'Feedback submitted successfully!',
                                        style: TextStyle(
                                            fontSize: 14 *
                                                responsive.fontSizeMultiplier),
                                      ),
                                      backgroundColor: AppTheme.primaryGreen,
                                    ),
                                  );
                                },
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: AppTheme.primaryGreen,
                                  foregroundColor: AppTheme.textInverse,
                                  padding: EdgeInsets.symmetric(
                                    vertical: responsive.spacing(16),
                                    horizontal: responsive.spacing(24),
                                  ),
                                ),
                                child: Text(
                                  'Submit Feedback',
                                  style: TextStyle(
                                      fontSize:
                                          16 * responsive.fontSizeMultiplier),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

// Compost Pits Page Widget
class _CompostPitsPage extends StatefulWidget {
  const _CompostPitsPage();

  @override
  State<_CompostPitsPage> createState() => _CompostPitsPageState();
}

class _CompostPitsPageState extends State<_CompostPitsPage> {
  String selectedFilter = 'All';
  String selectedSort = 'Distance';

  final List<Map<String, dynamic>> compostPits = [
    {
      'name': 'Victoria Community Compost Pit',
      'address': 'Victoria, Tago, Surigao del Sur',
      'distance': '0.5 km',
      'status': 'Open',
      'phone': '+63 912 345 6789',
      'hours': '6:00 AM - 6:00 PM',
    },
    {
      'name': 'Tago Municipal Compost Facility',
      'address': 'Tago Municipal Hall, Surigao del Sur',
      'distance': '2.1 km',
      'status': 'Open',
      'phone': '+63 912 345 6790',
      'hours': '7:00 AM - 5:00 PM',
    },
    {
      'name': 'Barangay Compost Center',
      'address': 'Barangay Hall, Tago, Surigao del Sur',
      'distance': '1.8 km',
      'status': 'Closed',
      'phone': '+63 912 345 6791',
      'hours': '8:00 AM - 4:00 PM',
    },
    {
      'name': 'Eco-Friendly Compost Site',
      'address': 'Eco Park, Tago, Surigao del Sur',
      'distance': '3.2 km',
      'status': 'Open',
      'phone': '+63 912 345 6792',
      'hours': '24/7',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final responsive = context.responsive;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'EcoSched',
                  style: AppTheme.titleLarge.copyWith(
                    color: AppTheme.textInverse,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(AppTheme.radiusM),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Image.asset(
                    'assets/images/house.gif',
                    fit: BoxFit.cover,
                  ),
                ),
              ],
            ),
          ],
        ),
        centerTitle: false,
        backgroundColor: AppTheme.primaryGreen,
        foregroundColor: AppTheme.textInverse,
      ),
      backgroundColor: Colors.grey[50],
      body: GradientBackground(
        economyTheme: true,
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              return SingleChildScrollView(
                padding: EdgeInsets.symmetric(
                  horizontal: responsive.horizontalPadding,
                  vertical: responsive.verticalPadding,
                ),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight: constraints.maxHeight,
                    maxWidth: responsive.getContainerWidth(
                      mobilePercent: 1.0,
                      tabletPercent: 0.9,
                      desktopPercent: 0.8,
                      maxWidth: 1000,
                    ),
                  ),
                  child: Column(
                    children: [
                      // Filter and Sort
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.all(responsive.spacing(16)),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 10,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: responsive.isMobile
                            ? Column(
                                children: [
                                  DropdownButtonFormField<String>(
                                    value: selectedFilter,
                                    decoration: InputDecoration(
                                      labelText: 'Filter',
                                      labelStyle: TextStyle(
                                          fontSize: 14 *
                                              responsive.fontSizeMultiplier),
                                      border: const OutlineInputBorder(),
                                      contentPadding: EdgeInsets.symmetric(
                                        horizontal: responsive.spacing(12),
                                        vertical: responsive.spacing(8),
                                      ),
                                    ),
                                    style: TextStyle(
                                        fontSize:
                                            14 * responsive.fontSizeMultiplier),
                                    items: ['All', 'Open', 'Closed']
                                        .map((String value) {
                                      return DropdownMenuItem<String>(
                                        value: value,
                                        child: Text(value),
                                      );
                                    }).toList(),
                                    onChanged: (String? newValue) {
                                      setState(() {
                                        selectedFilter = newValue!;
                                      });
                                    },
                                  ),
                                  SizedBox(height: responsive.spacing(12)),
                                  DropdownButtonFormField<String>(
                                    value: selectedSort,
                                    decoration: InputDecoration(
                                      labelText: 'Sort',
                                      labelStyle: TextStyle(
                                          fontSize: 14 *
                                              responsive.fontSizeMultiplier),
                                      border: const OutlineInputBorder(),
                                      contentPadding: EdgeInsets.symmetric(
                                        horizontal: responsive.spacing(12),
                                        vertical: responsive.spacing(8),
                                      ),
                                    ),
                                    style: TextStyle(
                                        fontSize:
                                            14 * responsive.fontSizeMultiplier),
                                    items: ['Distance', 'Name', 'Status']
                                        .map((String value) {
                                      return DropdownMenuItem<String>(
                                        value: value,
                                        child: Text(value),
                                      );
                                    }).toList(),
                                    onChanged: (String? newValue) {
                                      setState(() {
                                        selectedSort = newValue!;
                                      });
                                    },
                                  ),
                                ],
                              )
                            : Row(
                                children: [
                                  Expanded(
                                    child: DropdownButtonFormField<String>(
                                      value: selectedFilter,
                                      decoration: InputDecoration(
                                        labelText: 'Filter',
                                        labelStyle: TextStyle(
                                            fontSize: 14 *
                                                responsive.fontSizeMultiplier),
                                        border: const OutlineInputBorder(),
                                        contentPadding: EdgeInsets.symmetric(
                                          horizontal: responsive.spacing(12),
                                          vertical: responsive.spacing(8),
                                        ),
                                      ),
                                      style: TextStyle(
                                          fontSize: 14 *
                                              responsive.fontSizeMultiplier),
                                      items: ['All', 'Open', 'Closed']
                                          .map((String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: Text(value),
                                        );
                                      }).toList(),
                                      onChanged: (String? newValue) {
                                        setState(() {
                                          selectedFilter = newValue!;
                                        });
                                      },
                                    ),
                                  ),
                                  SizedBox(width: responsive.spacing(16)),
                                  Expanded(
                                    child: DropdownButtonFormField<String>(
                                      value: selectedSort,
                                      decoration: InputDecoration(
                                        labelText: 'Sort',
                                        labelStyle: TextStyle(
                                            fontSize: 14 *
                                                responsive.fontSizeMultiplier),
                                        border: const OutlineInputBorder(),
                                        contentPadding: EdgeInsets.symmetric(
                                          horizontal: responsive.spacing(12),
                                          vertical: responsive.spacing(8),
                                        ),
                                      ),
                                      style: TextStyle(
                                          fontSize: 14 *
                                              responsive.fontSizeMultiplier),
                                      items: ['Distance', 'Name', 'Status']
                                          .map((String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: Text(value),
                                        );
                                      }).toList(),
                                      onChanged: (String? newValue) {
                                        setState(() {
                                          selectedSort = newValue!;
                                        });
                                      },
                                    ),
                                  ),
                                ],
                              ),
                      ),
                      SizedBox(height: responsive.spacing(16)),
                      // Compost Pits List
                      ..._getFilteredAndSortedPits().map((pit) => Padding(
                            padding:
                                EdgeInsets.only(bottom: responsive.spacing(12)),
                            child:
                                _buildCompostPitCard(context, pit, responsive),
                          )),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  List<Map<String, dynamic>> _getFilteredAndSortedPits() {
    final List<Map<String, dynamic>> filtered = compostPits.where((pit) {
      if (selectedFilter == 'All') return true;
      return pit['status'] == selectedFilter;
    }).toList();

    int compareDistance(Map<String, dynamic> a, Map<String, dynamic> b) {
      double parseDistance(Map<String, dynamic> pit) {
        final String raw = pit['distance'] as String;
        final String numberPart = raw.split(' ').first;
        return double.tryParse(numberPart) ?? double.infinity;
      }

      return parseDistance(a).compareTo(parseDistance(b));
    }

    filtered.sort((a, b) {
      switch (selectedSort) {
        case 'Name':
          return (a['name'] as String).compareTo(b['name'] as String);
        case 'Status':
          return (a['status'] as String).compareTo(b['status'] as String);
        case 'Distance':
        default:
          return compareDistance(a, b);
      }
    });

    return filtered;
  }

  Future<void> _openPitDirections(Map<String, dynamic> pit) async {
    final String address = (pit['address'] ?? pit['name']) as String;
    final Uri mapsUri = Uri.parse(
      'https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(address)}',
    );

    if (await canLaunchUrl(mapsUri)) {
      await launchUrl(mapsUri, mode: LaunchMode.externalApplication);
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open directions')),
        );
      }
    }
  }

  Future<void> _callFacility(String phone) async {
    final Uri uri = Uri.parse('tel:$phone');

    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not make call')),
        );
      }
    }
  }

  Widget _buildCompostPitCard(
      BuildContext context, Map<String, dynamic> pit, Responsive responsive) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    pit['name'],
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: AppTheme.textDark,
                        ),
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: pit['status'] == 'Open'
                        ? AppTheme.lightGreen
                        : AppTheme.accentOrange,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    pit['status'],
                    style: const TextStyle(
                      color: AppTheme.textInverse,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(Icons.location_on, size: 16, color: AppTheme.textLight),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    pit['address'],
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: AppTheme.textLight,
                        ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Row(
              children: [
                Icon(Icons.schedule, size: 16, color: AppTheme.textLight),
                const SizedBox(width: 4),
                Text(
                  pit['hours'],
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppTheme.textLight,
                      ),
                ),
                const SizedBox(width: 16),
                Icon(Icons.navigation, size: 16, color: AppTheme.textLight),
                const SizedBox(width: 4),
                Text(
                  pit['distance'],
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: AppTheme.textLight,
                      ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () {
                      _openPitDirections(pit);
                    },
                    icon: const Icon(Icons.directions, size: 16),
                    label: const Text('Directions'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppTheme.primaryGreen,
                      side: BorderSide(color: AppTheme.primaryGreen),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton.icon(
                    onPressed: () {
                      _callFacility(pit['phone']);
                    },
                    icon: const Icon(Icons.phone, size: 16),
                    label: const Text('Call'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primaryGreen,
                      foregroundColor: AppTheme.textInverse,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// Notifications Page Widget
class _NotificationsPage extends StatefulWidget {
  const _NotificationsPage();

  @override
  State<_NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<_NotificationsPage> {
  final List<Map<String, dynamic>> notifications = [
    {
      'title': 'Collection Scheduled',
      'message': 'Your waste collection is scheduled for tomorrow at 8:00 AM',
      'time': '2 hours ago',
      'type': 'schedule',
      'isRead': false,
    },
    {
      'title': 'New Compost Pit Available',
      'message':
          'A new compost pit has been added near Victoria Community Center',
      'time': '1 day ago',
      'type': 'info',
      'isRead': false,
    },
    {
      'title': 'Feedback Response',
      'message':
          'Thank you for your feedback. We have implemented your suggestion.',
      'time': '2 days ago',
      'type': 'feedback',
      'isRead': true,
    },
    {
      'title': 'Collection Completed',
      'message':
          'Your waste has been successfully collected. Thank you for participating!',
      'time': '3 days ago',
      'type': 'success',
      'isRead': true,
    },
    {
      'title': 'Reminder: Sort Your Waste',
      'message':
          'Please remember to sort your waste properly for better recycling.',
      'time': '1 week ago',
      'type': 'reminder',
      'isRead': true,
    },
  ];

  @override
  Widget build(BuildContext context) {
    final responsive = context.responsive;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'EcoSched',
                  style: AppTheme.titleLarge.copyWith(
                    color: AppTheme.textInverse,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(AppTheme.radiusM),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Image.asset(
                    'assets/images/house.gif',
                    fit: BoxFit.cover,
                  ),
                ),
              ],
            ),
          ],
        ),
        centerTitle: false,
        backgroundColor: AppTheme.primaryGreen,
        foregroundColor: AppTheme.textInverse,
        actions: [
          TextButton(
            onPressed: () {
              setState(() {
                for (var notification in notifications) {
                  notification['isRead'] = true;
                }
              });
            },
            child: Text(
              'Mark All Read',
              style: TextStyle(
                color: AppTheme.textInverse,
                fontSize: 14 * responsive.fontSizeMultiplier,
              ),
            ),
          ),
        ],
      ),
      backgroundColor: Colors.grey[50],
      body: GradientBackground(
        economyTheme: true,
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              return SingleChildScrollView(
                padding: EdgeInsets.symmetric(
                  horizontal: responsive.horizontalPadding,
                  vertical: responsive.verticalPadding,
                ),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    minHeight: constraints.maxHeight,
                    maxWidth: responsive.getContainerWidth(
                      mobilePercent: 1.0,
                      tabletPercent: 0.9,
                      desktopPercent: 0.8,
                      maxWidth: 1000,
                    ),
                  ),
                  child: Column(
                    children: [
                      // Notification Stats
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.all(responsive.spacing(16)),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.05),
                              blurRadius: 10,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            _buildStatItem(
                              context,
                              'Unread',
                              notifications
                                  .where((n) => !n['isRead'])
                                  .length
                                  .toString(),
                              AppTheme.getEconomicColor('cost'),
                              responsive,
                            ),
                            _buildStatItem(
                              context,
                              'Total',
                              notifications.length.toString(),
                              AppTheme.getEconomicColor('profit'),
                              responsive,
                            ),
                            _buildStatItem(
                              context,
                              'This Week',
                              '3',
                              AppTheme.getEconomicColor('value'),
                              responsive,
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: responsive.spacing(16)),
                      // Notifications List
                      ...notifications.map((notification) {
                        return Padding(
                          padding:
                              EdgeInsets.only(bottom: responsive.spacing(12)),
                          child: _buildNotificationCard(
                              context, notification, responsive),
                        );
                      }),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildStatItem(BuildContext context, String label, String value,
      Color color, Responsive responsive) {
    return Column(
      children: [
        Text(
          value,
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
                color: color,
                fontSize:
                    (Theme.of(context).textTheme.headlineSmall?.fontSize ??
                            24) *
                        responsive.fontSizeMultiplier,
              ),
        ),
        Text(
          label,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: AppTheme.textLight,
                fontSize:
                    (Theme.of(context).textTheme.bodyMedium?.fontSize ?? 14) *
                        responsive.fontSizeMultiplier,
              ),
        ),
      ],
    );
  }

  Widget _buildNotificationCard(BuildContext context,
      Map<String, dynamic> notification, Responsive responsive) {
    return Card(
      margin: EdgeInsets.only(bottom: responsive.spacing(12)),
      child: ListTile(
        leading: Container(
          width: responsive.iconSize(40),
          height: responsive.iconSize(40),
          decoration: BoxDecoration(
            color: _getNotificationColor(notification['type']).withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Icon(
            _getNotificationIcon(notification['type']),
            color: _getNotificationColor(notification['type']),
            size: responsive.iconSize(20),
          ),
        ),
        title: Text(
          notification['title'],
          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                fontWeight: notification['isRead']
                    ? FontWeight.normal
                    : FontWeight.bold,
                color: AppTheme.textDark,
                fontSize:
                    (Theme.of(context).textTheme.titleMedium?.fontSize ?? 16) *
                        responsive.fontSizeMultiplier,
              ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              notification['message'],
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: AppTheme.textLight,
                    fontSize:
                        (Theme.of(context).textTheme.bodyMedium?.fontSize ??
                                14) *
                            responsive.fontSizeMultiplier,
                  ),
            ),
            SizedBox(height: responsive.spacing(4)),
            Text(
              notification['time'],
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: AppTheme.textLight,
                    fontSize:
                        (Theme.of(context).textTheme.bodySmall?.fontSize ??
                                12) *
                            responsive.fontSizeMultiplier,
                  ),
            ),
          ],
        ),
        trailing: notification['isRead']
            ? null
            : Container(
                width: responsive.iconSize(8),
                height: responsive.iconSize(8),
                decoration: const BoxDecoration(
                  color: AppTheme.accentOrange,
                  shape: BoxShape.circle,
                ),
              ),
        onTap: () {
          if (mounted) {
            setState(() {
              notification['isRead'] = true;
            });
          }
        },
      ),
    );
  }

  Color _getNotificationColor(String type) {
    switch (type) {
      case 'schedule':
        return AppTheme.primaryGreen;
      case 'info':
        return AppTheme.lightGreen;
      case 'feedback':
        return AppTheme.accentOrange;
      case 'success':
        return AppTheme.successGreen;
      case 'reminder':
        return AppTheme.infoBlue;
      default:
        return AppTheme.textLight;
    }
  }

  IconData _getNotificationIcon(String type) {
    switch (type) {
      case 'schedule':
        return Icons.schedule;
      case 'info':
        return Icons.info;
      case 'feedback':
        return Icons.feedback;
      case 'success':
        return Icons.check_circle;
      case 'reminder':
        return Icons.notifications;
      default:
        return Icons.notifications;
    }
  }
}
