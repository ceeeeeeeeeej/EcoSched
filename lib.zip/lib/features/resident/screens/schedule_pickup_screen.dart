import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/constants/app_constants.dart';
import '../../../core/animations/micro_interactions.dart';
import '../../../widgets/gradient_background.dart';
import '../../../widgets/glassmorphic_container.dart';
import '../../../widgets/animated_button.dart';
import '../../../widgets/animated_chip.dart';
import '../../../widgets/staggered_list.dart';
import '../../../widgets/animated_dialog.dart';

class SchedulePickupScreen extends StatefulWidget {
  const SchedulePickupScreen({super.key});

  @override
  State<SchedulePickupScreen> createState() => _SchedulePickupScreenState();
}

class _SchedulePickupScreenState extends State<SchedulePickupScreen>
    with TickerProviderStateMixin {
  String _selectedWasteType = 'General Waste';
  DateTime _selectedDate = DateTime.now().add(const Duration(days: 1));
  String _selectedTime = '9:00 AM';
  String _selectedLocation = 'Front Door';
  // String _notes = ''; // Unused for now

  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  final List<String> _wasteTypes = [
    'General Waste',
    'Recycling',
    'Organic Waste',
    'Hazardous Waste',
  ];

  final List<String> _timeSlots = [
    '8:00 AM',
    '9:00 AM',
    '10:00 AM',
    '11:00 AM',
    '2:00 PM',
    '3:00 PM',
    '4:00 PM',
  ];

  final List<String> _locations = [
    'Front Door',
    'Back Door',
    'Garage',
    'Side Entrance',
  ];

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    ));
    _fadeController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Schedule Pickup'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: GradientBackground(
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnimation,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(AppConstants.defaultPadding),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                // Header
                BounceInAnimation(
                  child: GlassmorphicContainer(
                    width: double.infinity,
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Schedule Your Pickup',
                          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                            fontWeight: FontWeight.bold,
                            color: AppTheme.textDark,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Choose your preferred date, time, and waste type',
                          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: AppTheme.textLight,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                
                // Waste Type Selection
                BounceInAnimation(
                  delay: const Duration(milliseconds: 200),
                  child: _buildSection(
                    'Waste Type',
                    Icons.delete_outline,
                    _buildWasteTypeSelector(),
                  ),
                ),
                const SizedBox(height: 20),
                
                // Date Selection
                BounceInAnimation(
                  delay: const Duration(milliseconds: 400),
                  child: _buildSection(
                    'Pickup Date',
                    Icons.calendar_today,
                    _buildDateSelector(),
                  ),
                ),
                const SizedBox(height: 20),
                
                // Time Selection
                BounceInAnimation(
                  delay: const Duration(milliseconds: 600),
                  child: _buildSection(
                    'Pickup Time',
                    Icons.access_time,
                    _buildTimeSelector(),
                  ),
                ),
                const SizedBox(height: 20),
                
                // Location Selection
                BounceInAnimation(
                  delay: const Duration(milliseconds: 800),
                  child: _buildSection(
                    'Pickup Location',
                    Icons.location_on,
                    _buildLocationSelector(),
                  ),
                ),
                const SizedBox(height: 20),
                
                // Notes
                BounceInAnimation(
                  delay: const Duration(milliseconds: 1000),
                  child: _buildSection(
                    'Additional Notes',
                    Icons.note,
                    _buildNotesField(),
                  ),
                ),
                const SizedBox(height: 32),
                
                // Schedule Button
                BounceInAnimation(
                  delay: const Duration(milliseconds: 1200),
                  child: AnimatedButton(
                    text: 'Schedule Pickup',
                    onPressed: _schedulePickup,
                    width: double.infinity,
                    icon: Icons.schedule,
                  ),
                ),
                const SizedBox(height: 16),
                
                // Cancel Button
                BounceInAnimation(
                  delay: const Duration(milliseconds: 1400),
                  child: AnimatedButton(
                    text: 'Cancel',
                    onPressed: () => Navigator.pop(context),
                    width: double.infinity,
                    backgroundColor: Colors.grey[600]!,
                    icon: Icons.close,
                  ),
                ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSection(String title, IconData icon, Widget content) {
    return GlassmorphicContainer(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: AppTheme.primaryGreen, size: 20),
              const SizedBox(width: 8),
              Text(
                title,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: AppTheme.textDark,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          content,
        ],
      ),
    );
  }

  Widget _buildWasteTypeSelector() {
    return AnimatedChipGroup(
      options: _wasteTypes,
      selectedOption: _selectedWasteType,
      onSelectionChanged: (value) => setState(() => _selectedWasteType = value),
      selectedColor: AppTheme.primaryGreen,
      unselectedColor: Colors.grey[200],
      selectedTextColor: Colors.white,
      unselectedTextColor: AppTheme.textDark,
      icon: Icons.delete_outline,
      selectedIcon: Icons.check,
    );
  }

  Widget _buildDateSelector() {
    return GestureDetector(
      onTap: _selectDate,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.grey[300]!),
        ),
        child: Row(
          children: [
            Icon(Icons.calendar_today, color: AppTheme.primaryGreen),
            const SizedBox(width: 12),
            Text(
              _formatDate(_selectedDate),
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                color: AppTheme.textDark,
                fontWeight: FontWeight.w500,
              ),
            ),
            const Spacer(),
            Icon(Icons.arrow_drop_down, color: AppTheme.textLight),
          ],
        ),
      ),
    );
  }

  Widget _buildTimeSelector() {
    return AnimatedChipGroup(
      options: _timeSlots,
      selectedOption: _selectedTime,
      onSelectionChanged: (value) => setState(() => _selectedTime = value),
      selectedColor: AppTheme.primaryGreen,
      unselectedColor: Colors.grey[200],
      selectedTextColor: Colors.white,
      unselectedTextColor: AppTheme.textDark,
      icon: Icons.access_time,
      selectedIcon: Icons.check,
    );
  }

  Widget _buildLocationSelector() {
    return Column(
      children: _locations.map((location) {
        return AnimatedRadio<String>(
          value: location,
          groupValue: _selectedLocation,
          onChanged: (value) => setState(() => _selectedLocation = value!),
          activeColor: AppTheme.primaryGreen,
          label: location,
        );
      }).toList(),
    );
  }

  Widget _buildNotesField() {
    return AnimatedTextField(
      onChanged: (value) {
        // Handle notes input if needed
      },
      hintText: 'Any special instructions or notes...',
      maxLines: 3,
    );
  }

  Future<void> _selectDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 30)),
    );
    if (date != null) {
      setState(() => _selectedDate = date);
    }
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year}';
  }

  void _schedulePickup() {
    AnimatedDialogUtils.showAnimatedDialog(
      context: context,
      child: AnimatedConfirmDialog(
        title: 'Pickup Scheduled!',
        content: 'Your ${_selectedWasteType.toLowerCase()} pickup has been scheduled for ${_formatDate(_selectedDate)} at $_selectedTime.',
        confirmText: 'OK',
        cancelText: '',
        onConfirm: () {
          Navigator.pop(context);
          Navigator.pop(context);
        },
        confirmColor: AppTheme.primaryGreen,
      ),
    );
  }
}
